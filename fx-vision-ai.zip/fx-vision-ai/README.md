# FX Vision AI

AI-powered crypto market analysis platform — "Earn While You Learn."

This is a standard **Next.js 14 (App Router)** project. The entire UI — hero,
candlestick chart, AI analysis flow, on-chain glossary, pricing, EN/FA i18n —
lives in a single client component at `components/FXVisionAI.jsx`, unchanged
from the working version, wired into a normal Next.js page.

## Project structure

```
fx-vision-ai/
├── app/
│   ├── layout.js        # root HTML shell
│   └── page.js          # renders <FXVisionAI />
├── components/
│   └── FXVisionAI.jsx   # the entire app (chart, AI analysis, i18n, etc.)
├── package.json
├── next.config.js
├── jsconfig.json         # enables the "@/components/..." import alias
└── .eslintrc.json
```

## Run it locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## About the chart

The candlestick chart renders with D3 and pulls **real, live candles directly
from Binance's public REST API** (`api.binance.com/api/v3/klines`) via
client-side `fetch` — no API key needed, no server route required. This code
was intentionally left exactly as-is.

This only works outside of Claude's own sandboxed preview, which blocks
outbound `fetch` calls to third-party domains. In a normal browser (localhost,
Vercel, any real hosting) there is no such restriction, since Binance's klines
endpoint is CORS-enabled for public market data — so the chart loads
correctly here.

## Deploy to Vercel

**Option A — via the Vercel dashboard**
1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. Go to https://vercel.com/new and import that repo.
3. Framework preset: Vercel auto-detects **Next.js** — no config needed.
4. Click **Deploy**.

**Option B — via the Vercel CLI**
```bash
npm install -g vercel
vercel
```
Follow the prompts (link or create a project, confirm the defaults), then:
```bash
vercel --prod
```

No environment variables are required for the current feature set — the app
has no backend yet (Supabase/OpenAI are not wired in; see the code comments
in `FXVisionAI.jsx` for where those would plug in later).
