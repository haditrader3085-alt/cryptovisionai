import FXVisionAI from "@/components/FXVisionAI";

export default function Home() {
  return <FXVisionAI />;
}
