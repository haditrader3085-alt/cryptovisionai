export const metadata = {
  title: "FX Vision AI — Earn While You Learn",
  description:
    "AI-powered crypto market analysis. Understand every signal instead of just following it.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, background: "#0B0B0B" }}>{children}</body>
    </html>
  );
}
