"use client";

import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import * as d3 from "d3";
import {
  Star, TrendingUp, TrendingDown, Minus, ChevronDown, Globe, Maximize2,
  Minimize2, User, BarChart3, Activity, Shield, Clock, Target, Zap,
  BookOpen, Check, ArrowRight, X, Menu, Sparkles, Crosshair, Radar,
  Waves, GraduationCap, Gauge, LineChart as LineChartIcon, RefreshCw, AlertTriangle
} from "lucide-react";

/* =====================================================================================
   FX VISION AI — "Earn While You Learn"
   A premium, dark, gold-accented AI crypto analysis platform.
   Design tokens are applied via inline styles (no Tailwind JIT / arbitrary values used).
===================================================================================== */

const COLORS = {
  bg: "#0B0B0B",
  bgElevated: "#0E0E0E",
  card: "#111111",
  cardHover: "#141414",
  border: "rgba(200,168,90,0.14)",
  borderStrong: "rgba(200,168,90,0.30)",
  gold: "#C8A85A",
  goldSoft: "rgba(200,168,90,0.10)",
  goldGlow: "rgba(200,168,90,0.20)",
  text: "#F2F0EA",
  textDim: "#9C9A93",
  textFaint: "#6C6A63",
  green: "#3FBE83",
  red: "#E0645A",
  divider: "rgba(255,255,255,0.06)",
};

const FONT_EN = "'Inter', -apple-system, BlinkMacSystemFont, sans-serif";
const FONT_FA = "'Vazirmatn', 'Inter', sans-serif";
const FONT_MONO = "'IBM Plex Mono', 'SF Mono', monospace";

/* --------------------------------- Coins / Symbols --------------------------------- */

const COINS = [
  { id: "BTC", name: "Bitcoin", tv: "BINANCE:BTCUSDT", binance: "BTCUSDT", price: 96420, change: 2.14 },
  { id: "ETH", name: "Ethereum", tv: "BINANCE:ETHUSDT", binance: "ETHUSDT", price: 3384, change: -0.87 },
  { id: "XRP", name: "XRP", tv: "BINANCE:XRPUSDT", binance: "XRPUSDT", price: 2.41, change: 4.32 },
  { id: "ADA", name: "Cardano", tv: "BINANCE:ADAUSDT", binance: "ADAUSDT", price: 0.842, change: -1.42 },
];

const TIMEFRAMES = ["15m", "1h", "4h", "1d"];

/* --------------------------------- Translations --------------------------------- */

const T = {
  en: {
    dir: "ltr", font: FONT_EN,
    nav: { markets: "Markets", ai: "AI Analysis", learn: "Learn", pricing: "Pricing" },
    slogan1: "Earn While You Learn",
    slogan2: "Understand every analysis, so you stop depending on other people's signals.",
    heroKicker: "Smart Market Analysis",
    rotatingTexts: [
      "💰 Learn while you earn.",
      "🔥 Read on-chain data like a pro.",
      "🎯 The AI built for serious traders.",
      "🧠 Understand the reason behind every buy and sell.",
    ],
    aiCaption: "AI scans over 50 market data points in under 10 seconds.",
    analyze: "Analyze Market",
    analyzing: "Analyzing…",
    scanSteps: ["Scanning Market…", "Reading On-chain…", "Reading Technical…", "Reading Derivatives…", "Generating AI Analysis…"],
    modeTrader: "Trader Mode",
    modeLearning: "Learning Mode",
    modeSub: "Trader shows the call. Learning shows the reasoning.",
    recommendation: "Recommendation",
    confidence: "Confidence",
    risk: "Risk",
    entryZone: "Entry Zone",
    takeProfit: "Take Profit",
    stopLoss: "Stop Loss",
    holdingTime: "Holding Time",
    scores: "Signal Scores",
    onchain: "On-chain", technical: "Technical", derivatives: "Derivatives",
    sentiment: "Sentiment", overall: "Overall",
    reasons: "Why This Call",
    whatDoesMean: "What does that mean?",
    watchlist: "Watchlist",
    fullscreen: "Fullscreen",
    exitFullscreen: "Exit Fullscreen",
    chartError: "Couldn't load live chart data.",
    chartRetry: "Retry",
    chartLoading: "Loading candles…",
    glossaryTitle: "Learn the Indicators",
    glossarySub: "Every metric behind every call — explained simply.",
    pricingTitle: "Pricing",
    pricingSub: "Start free. Upgrade when you're ready to go deeper.",
    perMonth: "/ month",
    getStarted: "Get Started",
    goPro: "Go Pro",
    contactUs: "Contact Us",
    profile: "Profile",
    guest: "Guest Trader",
    signIn: "Sign In",
    signOut: "Sign Out",
    dashboard: "Dashboard",
    onchainTitle: "On-chain Metrics, Explained Simply",
    onchainSub: "No jargon. Just what each number means and what to do with it.",
    onc_what: "What is it?",
    onc_why: "Why does it matter?",
    onc_today: "What does today's value mean?",
    onc_example: "A simple example",
    onc_takeaway: "The trading takeaway",
    riskLow: "Low", riskMed: "Medium", riskHigh: "High",
    buy: "BUY", sell: "SELL", hold: "HOLD",
    footerTagline: "AI market analysis for people who want to actually understand the market.",
    footerRights: "All rights reserved.",
    disclaimer: "FX Vision AI provides educational market analysis, not financial advice.",
  },
  fa: {
    dir: "rtl", font: FONT_FA,
    nav: { markets: "بازارها", ai: "تحلیل هوش مصنوعی", learn: "آموزش", pricing: "قیمت‌گذاری" },
    slogan1: "همزمان با یادگیری، درآمد کسب کن",
    slogan2: "هر تحلیل را بفهم؛ تا دیگر وابسته به سیگنال دیگران نباشی.",
    heroKicker: "تحلیل هوشمند بازار",
    rotatingTexts: [
      "💰 همزمان یاد بگیر، درآمد کسب کن.",
      "🔥 داده‌های آنچین را مثل حرفه‌ای‌ها بخوان.",
      "🎯 AI اختصاصی معامله‌گران حرفه‌ای.",
      "🧠 دلیل هر خرید و فروش را یاد بگیر.",
    ],
    aiCaption: "AI در کمتر از ۱۰ ثانیه بیش از ۵۰ داده بازار را تحلیل می‌کند.",
    analyze: "تحلیل بازار",
    analyzing: "در حال تحلیل…",
    scanSteps: ["اسکن بازار…", "بررسی آن‌چین…", "بررسی تکنیکال…", "بررسی مشتقات…", "تولید تحلیل هوش مصنوعی…"],
    modeTrader: "حالت معامله‌گر",
    modeLearning: "حالت یادگیری",
    modeSub: "حالت معامله‌گر فقط نتیجه را نشان می‌دهد؛ حالت یادگیری دلیل را توضیح می‌دهد.",
    recommendation: "پیشنهاد",
    confidence: "اطمینان",
    risk: "ریسک",
    entryZone: "محدوده ورود",
    takeProfit: "حد سود",
    stopLoss: "حد ضرر",
    holdingTime: "زمان نگهداری",
    scores: "امتیاز سیگنال‌ها",
    onchain: "آن‌چین", technical: "تکنیکال", derivatives: "مشتقات",
    sentiment: "احساسات بازار", overall: "کلی",
    reasons: "چرا این پیشنهاد",
    whatDoesMean: "یعنی چه؟",
    watchlist: "دیده‌بان",
    fullscreen: "تمام‌صفحه",
    exitFullscreen: "خروج از تمام‌صفحه",
    chartError: "دریافت داده زنده چارت ممکن نشد.",
    chartRetry: "تلاش مجدد",
    chartLoading: "در حال دریافت کندل‌ها…",
    glossaryTitle: "آموزش اندیکاتورها",
    glossarySub: "هر معیار پشت هر پیشنهاد — به زبان ساده.",
    pricingTitle: "قیمت‌گذاری",
    pricingSub: "رایگان شروع کن. هر وقت آماده بودی ارتقا بده.",
    perMonth: "/ ماه",
    getStarted: "شروع کن",
    goPro: "ارتقا به Pro",
    contactUs: "تماس با ما",
    profile: "پروفایل",
    guest: "معامله‌گر مهمان",
    signIn: "ورود",
    signOut: "خروج",
    dashboard: "داشبورد",
    onchainTitle: "متریک‌های آن‌چین، به زبان ساده",
    onchainSub: "بدون اصطلاح پیچیده. فقط این‌که هر عدد چه معنایی دارد و باید چه‌کار کنی.",
    onc_what: "این چیست؟",
    onc_why: "چرا مهم است؟",
    onc_today: "عدد امروز یعنی چه؟",
    onc_example: "یک مثال ساده",
    onc_takeaway: "نتیجه برای معامله",
    riskLow: "کم", riskMed: "متوسط", riskHigh: "زیاد",
    buy: "خرید", sell: "فروش", hold: "نگه‌داری",
    footerTagline: "تحلیل هوش مصنوعی بازار برای کسانی که واقعاً می‌خواهند بازار را بفهمند.",
    footerRights: "تمامی حقوق محفوظ است.",
    disclaimer: "FX Vision AI تحلیل آموزشی بازار ارائه می‌دهد، نه مشاوره مالی.",
  },
};

/* --------------------------------- Indicator Glossary (all explained) --------------------------------- */

const GLOSSARY = [
  { icon: Gauge, en: ["RSI", "Measures how fast and how far price has moved. Above 70 is often overbought, below 30 oversold."], fa: ["RSI", "سرعت و اندازه حرکت قیمت را می‌سنجد. بالای ۷۰ معمولاً اشباع خرید و زیر ۳۰ اشباع فروش است."] },
  { icon: Activity, en: ["MACD", "Compares two moving averages to show shifts in momentum and trend direction."], fa: ["MACD", "دو میانگین متحرک را مقایسه می‌کند تا تغییر مومنتوم و روند را نشان دهد."] },
  { icon: LineChartIcon, en: ["EMA", "An average price that reacts faster to recent candles than a simple average."], fa: ["EMA", "میانگین قیمتی که نسبت به کندل‌های اخیر واکنش سریع‌تری نشان می‌دهد."] },
  { icon: LineChartIcon, en: ["SMA", "A simple average of price over a period — smooths noise to reveal the trend."], fa: ["SMA", "میانگین ساده قیمت در یک بازه — نویز را حذف کرده و روند را نشان می‌دهد."] },
  { icon: Waves, en: ["Bollinger Bands", "Bands around price that widen with volatility — price hugging an edge can signal a move."], fa: ["باندهای بولینگر", "باندهایی اطراف قیمت که با نوسان گسترده‌تر می‌شوند — نزدیکی به لبه می‌تواند نشانه حرکت باشد."] },
  { icon: BarChart3, en: ["Volume", "How much was traded. Big moves on big volume are more reliable than on low volume."], fa: ["حجم", "میزان معاملات انجام‌شده. حرکت‌های بزرگ با حجم بالا معتبرتر از حجم پایین‌اند."] },
  { icon: Crosshair, en: ["Market Structure", "The pattern of highs and lows that reveals if buyers or sellers are in control."], fa: ["ساختار بازار", "الگوی سقف‌ها و کف‌ها که نشان می‌دهد خریداران یا فروشندگان کنترل را دارند."] },
  { icon: TrendingUp, en: ["Trend", "The dominant direction price has been moving — up, down, or sideways."], fa: ["روند", "جهت غالب حرکت قیمت — صعودی، نزولی یا خنثی."] },
  { icon: Shield, en: ["Support", "A price level where buying pressure has historically stopped a decline."], fa: ["حمایت", "سطح قیمتی که فشار خرید در گذشته جلوی افت را گرفته است."] },
  { icon: Shield, en: ["Resistance", "A price level where selling pressure has historically capped a rally."], fa: ["مقاومت", "سطح قیمتی که فشار فروش در گذشته جلوی رشد را گرفته است."] },
  { icon: Target, en: ["Open Interest", "The total number of open futures contracts — rising OI means fresh money entering."], fa: ["اوپن اینترست", "تعداد کل قراردادهای باز آتی — افزایش آن یعنی ورود سرمایه تازه."] },
  { icon: Zap, en: ["Funding Rate", "A fee traders pay each other in perpetual futures — extreme values signal crowded trades."], fa: ["فاندینگ ریت", "کارمزدی که معامله‌گران در قراردادهای دائمی می‌پردازند — مقادیر شدید نشانه ازدحام معاملات است."] },
  { icon: Radar, en: ["Liquidation", "Forced closing of leveraged positions — large liquidations can accelerate price moves."], fa: ["لیکوییدیشن", "بسته‌شدن اجباری پوزیشن‌های اهرمی — لیکوییدیشن‌های بزرگ می‌توانند حرکت قیمت را شدت دهند."] },
  { icon: Sparkles, en: ["Exchange Reserve", "How many coins sit on exchanges. Falling reserves often mean holders expect higher prices."], fa: ["ذخیره صرافی", "تعداد کوین‌های موجود در صرافی‌ها. کاهش آن معمولاً یعنی دارندگان انتظار رشد قیمت دارند."] },
  { icon: Waves, en: ["Whale Activity", "Large-wallet buying or selling. Big players often move before the wider market reacts."], fa: ["فعالیت نهنگ‌ها", "خرید یا فروش کیف‌پول‌های بزرگ. بازیگران بزرگ اغلب زودتر از بازار حرکت می‌کنند."] },
  { icon: Gauge, en: ["Fear & Greed", "A blended sentiment score — extreme fear or greed often precedes a reversal."], fa: ["ترس و طمع", "شاخص ترکیبی احساسات بازار — ترس یا طمع شدید معمولاً قبل از بازگشت روند رخ می‌دهد."] },
  { icon: BookOpen, en: ["On-chain Metrics", "Data read directly from the blockchain — wallet flows, holder behavior, network health."], fa: ["متریک‌های آن‌چین", "داده‌هایی مستقیماً از بلاکچین — جریان کیف‌پول‌ها، رفتار دارندگان، سلامت شبکه."] },
];

/* --------------------------------- On-chain Metrics: full beginner explanations --------------------------------- */
/* Each item follows the 5-part structure: what / why / today / example / takeaway */

const ONCHAIN_METRICS = [
  {
    icon: Target,
    en: {
      name: "Open Interest (OI)",
      what: "Open Interest is the total number of futures contracts that are still open right now — positions traders have opened but not yet closed.",
      why: "It tells you how much money is actively betting on price direction. Rising OI means new money is entering the market; falling OI means people are closing positions and leaving.",
      today: "If OI is rising while price also rises, it usually means new buyers are stepping in — the move has real backing. If OI rises while price falls, new sellers are piling in.",
      example: "Think of OI like the number of people still standing in a betting line. More people joining the line while the game is going their way means growing confidence in that direction.",
      takeaway: "Rising OI + rising price = healthy uptrend. Rising OI + falling price = growing bearish pressure. Falling OI = the move may be running out of fuel.",
    },
    fa: {
      name: "اوپن اینترست (Open Interest)",
      what: "اوپن اینترست یعنی تعداد کل قراردادهای فیوچرزی که هنوز باز هستند — یعنی پوزیشن‌هایی که معامله‌گران باز کرده‌اند ولی هنوز نبسته‌اند.",
      why: "این عدد نشان می‌دهد چقدر پول واقعی روی جهت قیمت شرط بسته شده. افزایش اوپن اینترست یعنی پول تازه وارد بازار می‌شود؛ کاهش آن یعنی افراد پوزیشن‌هایشان را می‌بندند و از بازار خارج می‌شوند.",
      today: "اگر اوپن اینترست همراه با افزایش قیمت بالا برود، معمولاً یعنی خریداران تازه وارد شده‌اند و این حرکت پشتوانه واقعی دارد. اگر اوپن اینترست بالا برود ولی قیمت پایین بیاید، یعنی فروشندگان تازه در حال ورود هستند.",
      example: "اوپن اینترست را مثل صف افرادی تصور کن که روی نتیجه یک بازی شرط بسته‌اند. اگر افراد بیشتری به صف بپیوندند درحالی‌که بازی به نفعشان پیش می‌رود، یعنی اطمینان به آن جهت در حال افزایش است.",
      takeaway: "اوپن اینترست بالا + قیمت بالا = روند صعودی سالم. اوپن اینترست بالا + قیمت پایین = فشار نزولی در حال رشد. اوپن اینترست پایین = ممکن است حرکت فعلی داره ضعیف می‌شود.",
    },
  },
  {
    icon: Zap,
    en: {
      name: "Funding Rate",
      what: "In perpetual futures, traders holding long positions and traders holding short positions periodically pay each other a small fee. That fee is the Funding Rate.",
      why: "It shows which side of the market is more crowded. When too many people are betting the same direction with leverage, funding becomes extreme — and extreme crowding is often followed by a sharp reversal.",
      today: "A slightly positive rate means longs are paying shorts — normal, healthy bullish demand. A very high positive rate means longs are overcrowded and a squeeze lower is more likely. A negative rate means shorts are paying longs, showing bearish positioning.",
      example: "Imagine a see-saw with far more people sitting on one side. The side with more weight (crowd) has to pay the smaller side just to keep playing. If that imbalance gets too extreme, the see-saw eventually snaps back.",
      takeaway: "Mildly positive funding is healthy. Extremely positive or negative funding is a warning sign — the crowd is too one-sided, and a reversal or a sharp move against that crowd becomes more likely.",
    },
    fa: {
      name: "فاندینگ ریت (Funding Rate)",
      what: "در بازار فیوچرز دائمی (پرپچوال)، معامله‌گران لانگ و شورت هر چند ساعت یک‌بار مبلغ کوچکی به یکدیگر می‌پردازند. این مبلغ همان فاندینگ ریت است.",
      why: "این عدد نشان می‌دهد کدام سمت بازار شلوغ‌تر است. وقتی افراد زیادی با اهرم روی یک جهت شرط بسته باشند، فاندینگ به عدد شدیدی می‌رسد — و ازدحام شدید معمولاً با یک بازگشت ناگهانی همراه می‌شود.",
      today: "فاندینگ کمی مثبت یعنی لانگ‌ها به شورت‌ها پول می‌دهند — طبیعی و نشانه تقاضای صعودی سالم است. فاندینگ خیلی بالا یعنی سمت لانگ خیلی شلوغ شده و احتمال یک افت شدید (اسکوییز) بیشتر می‌شود. فاندینگ منفی یعنی شورت‌ها به لانگ‌ها پول می‌دهند که نشان‌دهنده پوزیشن‌گیری نزولی است.",
      example: "مثل یک الاکلنگ که خیلی‌ها روی یک طرفش نشسته‌اند. طرف سنگین‌تر (شلوغ‌تر) باید به طرف سبک‌تر پول بدهد فقط برای این‌که بازی ادامه پیدا کند. وقتی این عدم تعادل خیلی زیاد شود، بالاخره الاکلنگ برمی‌گردد.",
      takeaway: "فاندینگ کمی مثبت یعنی وضعیت سالم است. فاندینگ خیلی مثبت یا خیلی منفی یک هشدار است — یک طرف بازار خیلی شلوغ شده و احتمال بازگشت یا حرکت شدید علیه آن جمع بیشتر می‌شود.",
    },
  },
  {
    icon: Sparkles,
    en: {
      name: "Exchange Reserve",
      what: "Exchange Reserve is simply how many coins are currently sitting inside exchange wallets, ready to be sold at any moment.",
      why: "Coins sitting on an exchange can be sold instantly with one click. Coins moved off an exchange, into private wallets, usually can't be sold quickly — so they represent lower near-term selling pressure.",
      today: "When the reserve is falling, it usually means people are withdrawing coins to hold long-term — a sign of confidence. When the reserve is rising, coins are flowing in, often preparing to be sold.",
      example: "Think of an exchange like a store's shelf. Coins on the shelf can be bought or sold right now. When people take coins home and put them in a safe, those coins are no longer available for a quick sale.",
      takeaway: "Falling reserves = fewer coins available to sell = often bullish over time. Rising reserves = more coins ready to hit the market = a caution sign.",
    },
    fa: {
      name: "ذخیره صرافی (Exchange Reserve)",
      what: "ذخیره صرافی یعنی چه تعداد کوین همین الان داخل کیف‌پول‌های صرافی‌ها نشسته و آماده فروش فوری است.",
      why: "کوینی که داخل صرافی است را می‌شود با یک کلیک فروخت. کوینی که از صرافی خارج و به کیف‌پول شخصی منتقل شده، معمولاً نمی‌تواند سریع فروخته شود — پس فشار فروش کوتاه‌مدت کمتری دارد.",
      today: "وقتی ذخیره صرافی در حال کاهش است، معمولاً یعنی افراد کوین‌هایشان را برداشت کرده‌اند تا بلندمدت نگه دارند — نشانه‌ای از اطمینان. وقتی ذخیره در حال افزایش است، کوین‌ها به صرافی وارد می‌شوند که اغلب برای فروش آماده می‌شوند.",
      example: "صرافی را مثل قفسه یک مغازه تصور کن. کوینی که روی قفسه است را می‌شود همین الان خرید یا فروخت. وقتی افراد کوین را به خانه می‌برند و در گاوصندوق می‌گذارند، دیگر برای فروش سریع در دسترس نیست.",
      takeaway: "کاهش ذخیره = کوین کمتری آماده فروش = معمولاً در بلندمدت صعودی است. افزایش ذخیره = کوین بیشتری آماده ورود به بازار = یک نشانه احتیاط.",
    },
  },
  {
    icon: Waves,
    en: {
      name: "Whale Activity",
      what: "\"Whales\" are wallets holding very large amounts of a coin. Whale Activity tracks when these big wallets buy or sell in size.",
      why: "Whales move markets. Because they trade such large amounts, their buying or selling can shift price on its own — and they often act on information or conviction before the wider market catches on.",
      today: "When whale wallets are accumulating (buying), it often signals confidence in future price growth. When whales are distributing (selling), it can add real supply pressure to the market.",
      example: "Imagine one person buying 1,000 concert tickets versus a thousand people buying one ticket each. The first case can single-handedly sell out the show — that's the kind of impact a whale can have on price.",
      takeaway: "Track whale buying as a supportive signal and whale selling as a warning sign — but always check it alongside other data, since a single whale move doesn't guarantee direction.",
    },
    fa: {
      name: "فعالیت نهنگ‌ها (Whale Activity)",
      what: "\"نهنگ‌ها\" کیف‌پول‌هایی هستند که مقدار خیلی زیادی از یک کوین را نگه می‌دارند. فعالیت نهنگ‌ها یعنی ردیابی این‌که این کیف‌پول‌های بزرگ کی خرید یا فروش سنگین انجام می‌دهند.",
      why: "نهنگ‌ها بازار را تکان می‌دهند. چون حجم معاملاتشان خیلی زیاد است، خرید یا فروششان به‌تنهایی می‌تواند قیمت را جابه‌جا کند — و اغلب زودتر از بقیه بازار بر اساس اطلاعات یا اطمینانشان دست به کار می‌شوند.",
      today: "وقتی کیف‌پول‌های نهنگ در حال انباشت (خرید) هستند، معمولاً نشانه اطمینان به رشد آینده قیمت است. وقتی نهنگ‌ها در حال توزیع (فروش) هستند، می‌تواند فشار عرضه واقعی به بازار وارد کند.",
      example: "فرض کن یک نفر ۱۰۰۰ بلیت کنسرت می‌خرد در مقابل هزار نفر که هرکدام یک بلیت می‌خرند. حالت اول می‌تواند به‌تنهایی همه بلیت‌ها را تمام کند — نهنگ‌ها هم چنین تأثیری روی قیمت دارند.",
      takeaway: "خرید نهنگ‌ها را به‌عنوان سیگنال حمایتی و فروش آن‌ها را به‌عنوان هشدار در نظر بگیر — ولی همیشه آن را کنار داده‌های دیگر بررسی کن، چون یک حرکت تنها از یک نهنگ جهت قطعی بازار را تضمین نمی‌کند.",
    },
  },
  {
    icon: Activity,
    en: {
      name: "CVD (Cumulative Volume Delta)",
      what: "CVD tracks the running difference between aggressive buying (market buy orders) and aggressive selling (market sell orders) over time.",
      why: "Price can sometimes move up on weak buying and heavy hidden selling, or the reverse. CVD reveals what's really happening underneath the price — who is actually in control, buyers or sellers.",
      today: "If CVD is rising alongside price, buyers are genuinely in control and the move looks healthy. If price rises but CVD is falling or flat, buying pressure is weaker than it looks — a warning sign of a possible reversal.",
      example: "Imagine a tug-of-war. The rope's position is the price, but CVD tells you how hard each side is actually pulling. Sometimes the rope moves a little even though one side is barely trying — that's the divergence CVD helps you spot.",
      takeaway: "Use CVD to confirm a price move. Price and CVD moving together = a trustworthy move. Price and CVD disagreeing = be cautious, the move may not last.",
    },
    fa: {
      name: "CVD (دلتای تجمعی حجم)",
      what: "CVD اختلاف تجمعی بین خرید تهاجمی (سفارش‌های خرید بازار) و فروش تهاجمی (سفارش‌های فروش بازار) را در طول زمان دنبال می‌کند.",
      why: "گاهی قیمت با خرید ضعیف و فروش پنهانِ سنگین بالا می‌رود، یا برعکس. CVD نشان می‌دهد واقعاً زیر پوست قیمت چه خبر است — واقعاً خریداران کنترل دارند یا فروشندگان.",
      today: "اگر CVD همراه با قیمت در حال افزایش باشد، خریداران واقعاً کنترل دارند و حرکت سالم به نظر می‌رسد. اگر قیمت بالا برود ولی CVD ثابت یا در حال کاهش باشد، فشار خرید ضعیف‌تر از چیزی است که به نظر می‌رسد — هشدار احتمال بازگشت روند.",
      example: "طناب‌کشی را تصور کن. موقعیت طناب همان قیمت است، ولی CVD نشان می‌دهد هر طرف واقعاً چقدر زور می‌زند. گاهی طناب کمی حرکت می‌کند درحالی‌که یک طرف اصلاً زور نمی‌زند — این همان واگرایی‌ای است که CVD کمک می‌کند ببینی.",
      takeaway: "از CVD برای تأیید حرکت قیمت استفاده کن. هم‌جهت‌بودن قیمت و CVD یعنی حرکت قابل‌اعتماد. ناهم‌جهت‌بودنشان یعنی احتیاط کن، چون ممکن است حرکت دوام نیاورد.",
    },
  },
  {
    icon: Radar,
    en: {
      name: "Liquidations",
      what: "A liquidation happens when a leveraged trader's position is forcibly closed by the exchange because they ran out of margin to keep it open.",
      why: "Large liquidations act like fuel on a fire — when many leveraged positions get force-closed at once, the forced buying or selling can accelerate a price move sharply in a very short time.",
      today: "A spike in long liquidations means over-leveraged buyers just got flushed out, often after a sharp drop — this can mark a local bottom. A spike in short liquidations means overleveraged sellers got squeezed, often after a sharp rally — this can mark a local top.",
      example: "Think of a game of musical chairs played with borrowed chairs. When the music stops, whoever ran out of chairs (margin) is forced out immediately, all at once — creating a sudden, sharp move.",
      takeaway: "Big liquidation spikes often mark short-term extremes, not the start of a new trend. Watch for them as exhaustion signals, not confirmation of a new direction.",
    },
    fa: {
      name: "لیکوییدیشن (Liquidations)",
      what: "لیکوییدیشن یعنی وقتی پوزیشن یک معامله‌گر اهرم‌دار به‌اجبار توسط صرافی بسته می‌شود، چون مارجین کافی برای باز نگه‌داشتن آن نداشته است.",
      why: "لیکوییدیشن‌های بزرگ مثل ریختن بنزین روی آتش عمل می‌کنند — وقتی خیلی از پوزیشن‌های اهرم‌دار همزمان به‌اجبار بسته می‌شوند، خرید یا فروش اجباری می‌تواند حرکت قیمت را در مدت‌زمان خیلی کوتاه شدت دهد.",
      today: "افزایش ناگهانی لیکوییدیشن لانگ یعنی خریداران بیش‌ازحد اهرم‌دار، معمولاً بعد از یک افت شدید، خارج شده‌اند — این می‌تواند یک کف موقت را نشان دهد. افزایش لیکوییدیشن شورت یعنی فروشندگان بیش‌ازحد اهرم‌دار بعد از یک رشد شدید فشرده شده‌اند — این می‌تواند یک سقف موقت را نشان دهد.",
      example: "مثل بازی صندلی‌بازی با صندلی‌های قرضی. وقتی موسیقی متوقف می‌شود، هرکس صندلی (مارجین) کافی نداشته باشد بلافاصله و همزمان با همه بیرون انداخته می‌شود — و همین یک حرکت ناگهانی و شدید ایجاد می‌کند.",
      takeaway: "افزایش‌های بزرگ لیکوییدیشن معمولاً یک نقطه افراطی کوتاه‌مدت را نشان می‌دهند، نه شروع یک روند جدید. آن‌ها را نشانه خستگی بازار ببین، نه تأیید یک جهت جدید.",
    },
  },
  {
    icon: Gauge,
    en: {
      name: "OI Delta",
      what: "OI Delta measures how much Open Interest has changed over a specific period — for example, how many new contracts opened in the last hour versus the hour before.",
      why: "The direction of price tells you where the market went. OI Delta tells you how much fresh conviction is behind that move — a big change means something meaningful is happening right now, not just noise.",
      today: "A large positive OI Delta during a price rise shows strong fresh buying interest just opened. A large positive OI Delta during a price drop shows strong fresh selling interest just opened.",
      example: "It's like checking not just how many people are in a stadium, but how many just walked through the gate in the last five minutes. A sudden rush at the gate tells you something is happening right now.",
      takeaway: "A sharp OI Delta spike alongside a price move adds confidence that new money — not just existing positions — is driving the current move.",
    },
    fa: {
      name: "OI Delta",
      what: "OI Delta میزان تغییر اوپن اینترست در یک بازه زمانی مشخص را اندازه می‌گیرد — مثلاً چند قرارداد جدید در یک ساعت اخیر نسبت به ساعت قبل باز شده.",
      why: "جهت قیمت به تو می‌گوید بازار کجا رفته. OI Delta به تو می‌گوید چقدر اطمینان تازه پشت این حرکت است — تغییر بزرگ یعنی همین الان اتفاق مهمی در حال رخ‌دادن است، نه فقط نویز.",
      today: "OI Delta مثبت و بزرگ همراه با رشد قیمت یعنی علاقه خرید تازه و قوی همین الان باز شده. OI Delta مثبت و بزرگ همراه با افت قیمت یعنی علاقه فروش تازه و قوی همین الان باز شده.",
      example: "مثل این‌که فقط تعداد افراد داخل استادیوم را نگاه نکنی، بلکه ببینی چند نفر همین پنج دقیقه اخیر از دروازه وارد شده‌اند. هجوم ناگهانی به دروازه نشان می‌دهد همین الان یک اتفاق در حال رخ‌دادن است.",
      takeaway: "جهش شدید OI Delta همراه با حرکت قیمت این اطمینان را می‌دهد که پول تازه — نه فقط پوزیشن‌های قبلی — پشت حرکت فعلی است.",
    },
  },
];

/* --------------------------------- Reason signal pool --------------------------------- */

const SIGNAL_POOL = [
  { cat: "onchain", en: { bullish: ["Whales are buying.", "Large wallets have been accumulating over the past days. Whales are investors with very large capital — when they buy in size, it often signals confidence in future price growth."], bearish: ["Whales are distributing.", "Large wallets have been reducing their holdings. When whales sell in size, it can add supply pressure and often signals reduced confidence near-term."], neutral: ["Whale activity is quiet.", "No unusual large-wallet movement was detected. Quiet whale activity usually means the market is waiting for a clearer trigger."] },
    fa: { bullish: ["نهنگ‌ها در حال خرید هستند.", "کیف‌پول‌های بزرگ در روزهای اخیر در حال انباشت بوده‌اند. نهنگ‌ها سرمایه‌گذاران بزرگ هستند — خرید سنگین آن‌ها معمولاً نشانه اطمینان به رشد آینده قیمت است."], bearish: ["نهنگ‌ها در حال توزیع دارایی هستند.", "کیف‌پول‌های بزرگ دارایی خود را کاهش داده‌اند. فروش سنگین نهنگ‌ها می‌تواند فشار عرضه ایجاد کرده و نشانه کاهش اطمینان کوتاه‌مدت باشد."], neutral: ["فعالیت نهنگ‌ها آرام است.", "حرکت غیرعادی از کیف‌پول‌های بزرگ دیده نشده. آرامش نهنگ‌ها معمولاً یعنی بازار منتظر یک محرک واضح‌تر است."] } },
  { cat: "onchain", en: { bullish: ["Exchange reserves are decreasing.", "Coins are leaving exchanges. This usually means investors are holding instead of selling, which can reduce selling pressure."], bearish: ["Exchange reserves are increasing.", "Coins are flowing onto exchanges. This often means holders are preparing to sell, which can add selling pressure."], neutral: ["Exchange reserves are stable.", "No major shift in exchange balances. A stable reserve suggests neither strong accumulation nor distribution right now."] },
    fa: { bullish: ["ذخیره صرافی‌ها در حال کاهش است.", "کوین‌ها از صرافی‌ها خارج می‌شوند. این معمولاً یعنی سرمایه‌گذاران به‌جای فروش، دارایی را نگه می‌دارند که می‌تواند فشار فروش را کاهش دهد."], bearish: ["ذخیره صرافی‌ها در حال افزایش است.", "کوین‌ها به صرافی‌ها وارد می‌شوند. این اغلب یعنی دارندگان در حال آماده‌شدن برای فروش هستند که می‌تواند فشار فروش ایجاد کند."], neutral: ["ذخیره صرافی‌ها ثابت است.", "تغییر عمده‌ای در موجودی صرافی‌ها دیده نشده. ثبات ذخیره یعنی نه انباشت قوی و نه توزیع قوی در حال حاضر."] } },
  { cat: "derivatives", en: { bullish: ["Funding Rate is mildly positive.", "Longs are paying shorts a small fee. This shows healthy bullish demand without excessive leverage — a sustainable kind of optimism."], bearish: ["Funding Rate is negative.", "Shorts are paying longs. This shows bearish positioning is building, which can pressure price lower if it continues."], neutral: ["Funding Rate is neutral.", "Funding sits close to zero — the perpetual futures market isn't crowded on either side right now, reducing squeeze risk."] },
    fa: { bullish: ["فاندینگ ریت کمی مثبت است.", "پوزیشن‌های لانگ کارمزد کمی به شورت‌ها می‌پردازند. این نشان‌دهنده تقاضای صعودی سالم بدون اهرم بیش‌ازحد است."], bearish: ["فاندینگ ریت منفی است.", "شورت‌ها به لانگ‌ها کارمزد می‌پردازند. این نشان می‌دهد پوزیشن‌گیری نزولی در حال شکل‌گیری است."], neutral: ["فاندینگ ریت خنثی است.", "فاندینگ نزدیک صفر است — بازار فیوچرز دائمی در حال حاضر در هیچ سمتی شلوغ نیست و ریسک اسکوییز کم است."] } },
  { cat: "derivatives", en: { bullish: ["Open Interest is rising with price.", "New money is entering the market alongside rising price — a healthy sign that the move is backed by fresh positioning."], bearish: ["Open Interest is rising while price falls.", "New short positions may be entering as price drops, which can add pressure to the downside."], neutral: ["Open Interest is flat.", "Little new capital is entering futures markets right now — the current move is likely driven by existing positions, not new demand."] },
    fa: { bullish: ["اوپن اینترست همراه با قیمت در حال افزایش است.", "سرمایه تازه همزمان با رشد قیمت وارد بازار می‌شود — نشانه سالمی از پشتیبانی پوزیشن‌های جدید از این حرکت."], bearish: ["اوپن اینترست در حال افزایش و قیمت در حال کاهش است.", "ممکن است پوزیشن‌های شورت جدید همزمان با افت قیمت وارد شوند که می‌تواند فشار نزولی ایجاد کند."], neutral: ["اوپن اینترست تقریباً بدون تغییر است.", "سرمایه تازه چندانی وارد بازار فیوچرز نمی‌شود — حرکت فعلی احتمالاً ناشی از پوزیشن‌های موجود است، نه تقاضای جدید."] } },
  { cat: "technical", en: { bullish: ["RSI is healthy.", "RSI sits in a balanced range, not overbought. There is room for price to keep rising before momentum becomes stretched."], bearish: ["RSI is overbought.", "RSI has moved into a stretched zone. This can precede a pullback as momentum cools off."], neutral: ["RSI is neutral.", "RSI sits near the midpoint, showing no strong momentum bias in either direction right now."] },
    fa: { bullish: ["RSI در محدوده سالم است.", "RSI در محدوده‌ای متعادل و نه اشباع خرید قرار دارد. فضا برای ادامه رشد قیمت پیش از کشیده‌شدن مومنتوم وجود دارد."], bearish: ["RSI در اشباع خرید است.", "RSI به ناحیه کشیده‌شده رسیده. این می‌تواند پیش از یک اصلاح، با کاهش مومنتوم همراه باشد."], neutral: ["RSI خنثی است.", "RSI نزدیک نقطه میانی قرار دارد و مومنتوم قوی در هیچ جهتی نشان نمی‌دهد."] } },
  { cat: "technical", en: { bullish: ["Market structure remains bullish.", "Price is forming higher highs and higher lows. This pattern shows buyers are still in control of the trend."], bearish: ["Market structure has turned bearish.", "Price is forming lower highs and lower lows, showing sellers have taken control of the short-term trend."], neutral: ["Market structure is ranging.", "Price is moving sideways between clear support and resistance, without a dominant trend either way."] },
    fa: { bullish: ["ساختار بازار همچنان صعودی است.", "قیمت سقف‌ها و کف‌های بالاتر می‌سازد. این الگو نشان می‌دهد خریداران هنوز کنترل روند را در دست دارند."], bearish: ["ساختار بازار نزولی شده است.", "قیمت سقف‌ها و کف‌های پایین‌تر می‌سازد که نشان می‌دهد فروشندگان کنترل روند کوتاه‌مدت را گرفته‌اند."], neutral: ["ساختار بازار رنج است.", "قیمت بین حمایت و مقاومت مشخصی نوسان می‌کند، بدون روند غالب در هیچ جهتی."] } },
  { cat: "sentiment", en: { bullish: ["Fear & Greed shows cautious optimism.", "Sentiment has shifted away from fear without reaching greed — historically a favorable zone for continued upside."], bearish: ["Fear & Greed shows rising fear.", "Sentiment has shifted toward fear, which often coincides with weaker short-term price action."], neutral: ["Fear & Greed is balanced.", "Sentiment sits in a neutral zone, suggesting the crowd has no strong emotional bias right now."] },
    fa: { bullish: ["شاخص ترس و طمع خوش‌بینی محتاطانه را نشان می‌دهد.", "احساسات از ترس فاصله گرفته بدون رسیدن به طمع — از نظر تاریخی منطقه‌ای مناسب برای ادامه رشد است."], bearish: ["شاخص ترس و طمع افزایش ترس را نشان می‌دهد.", "احساسات به‌سمت ترس چرخیده که اغلب با ضعف قیمت در کوتاه‌مدت همراه است."], neutral: ["شاخص ترس و طمع متعادل است.", "احساسات در ناحیه خنثی قرار دارد که یعنی جمع بازار سوگیری احساسی قوی ندارد."] } },
  { cat: "technical", en: { bullish: ["Volume confirms the move.", "The recent price advance came on rising volume, which adds conviction that the move is genuine rather than a low-liquidity spike."], bearish: ["Volume is declining on the rally.", "Price is rising but volume is fading — a divergence that can warn the move is losing strength."], neutral: ["Volume is average.", "Trading volume is in line with recent norms, offering no strong confirmation or warning signal."] },
    fa: { bullish: ["حجم معاملات حرکت را تأیید می‌کند.", "رشد اخیر قیمت با افزایش حجم همراه بوده که اطمینان می‌دهد این حرکت واقعی است، نه یک جهش کم‌نقدینگی."], bearish: ["حجم معاملات در رشد اخیر کاهش یافته.", "قیمت در حال رشد است اما حجم در حال کاهش — واگرایی‌ای که می‌تواند هشدار ضعف حرکت باشد."], neutral: ["حجم معاملات میانگین است.", "حجم معاملات مطابق روند اخیر است و سیگنال تأیید یا هشدار قوی‌ای نمی‌دهد."] } },
];

/* --------------------------------- Analysis engine (mock, deterministic-ish) --------------------------------- */

function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function generateAnalysis(coin) {
  const seed = coin.id.split("").reduce((a, c) => a + c.charCodeAt(0), 0) + Date.now() % 1000;
  const rnd = seededRandom(seed);

  const scoreOnchain = Math.round(30 + rnd() * 65);
  const scoreTechnical = Math.round(30 + rnd() * 65);
  const scoreDerivatives = Math.round(30 + rnd() * 65);
  const scoreSentiment = Math.round(30 + rnd() * 65);
  const overall = Math.round((scoreOnchain + scoreTechnical + scoreDerivatives + scoreSentiment) / 4);

  let recommendation = "HOLD";
  if (overall >= 62) recommendation = "BUY";
  else if (overall <= 40) recommendation = "SELL";

  const confidence = Math.min(96, Math.max(52, overall + Math.round(rnd() * 10 - 5)));
  const riskRoll = rnd();
  const risk = riskRoll < 0.34 ? "low" : riskRoll < 0.72 ? "medium" : "high";

  const price = coin.price;
  const entryLow = +(price * (0.985 + rnd() * 0.006)).toFixed(price < 10 ? 4 : 2);
  const entryHigh = +(price * (0.996 + rnd() * 0.006)).toFixed(price < 10 ? 4 : 2);
  const tp = +(price * (recommendation === "SELL" ? 0.90 - rnd() * 0.05 : 1.08 + rnd() * 0.07)).toFixed(price < 10 ? 4 : 2);
  const sl = +(price * (recommendation === "SELL" ? 1.04 + rnd() * 0.02 : 0.94 - rnd() * 0.02)).toFixed(price < 10 ? 4 : 2);
  const holdOptions = ["2–4 days", "1–2 weeks", "3–5 days", "1–3 days", "2–3 weeks"];
  const holdingTime = holdOptions[Math.floor(rnd() * holdOptions.length)];

  const directionFor = (base) => {
    const roll = rnd();
    if (recommendation === "BUY") return roll < 0.75 ? "bullish" : "neutral";
    if (recommendation === "SELL") return roll < 0.75 ? "bearish" : "neutral";
    return roll < 0.4 ? "bullish" : roll < 0.8 ? "bearish" : "neutral";
  };

  const shuffled = [...SIGNAL_POOL].sort(() => rnd() - 0.5).slice(0, 5);
  const reasons = shuffled.map((sig) => ({
    cat: sig.cat,
    direction: directionFor(sig),
    en: sig.en,
    fa: sig.fa,
  }));

  return {
    recommendation, confidence, risk,
    entryLow, entryHigh, tp, sl, holdingTime,
    scores: { onchain: scoreOnchain, technical: scoreTechnical, derivatives: scoreDerivatives, sentiment: scoreSentiment, overall },
    reasons,
  };
}

/* =====================================================================================
   UI PRIMITIVES
===================================================================================== */

function GlassCard({ children, style, className = "", hover = false }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className={className}
      onMouseEnter={() => hover && setHovered(true)}
      onMouseLeave={() => hover && setHovered(false)}
      style={{
        background: `linear-gradient(180deg, ${COLORS.card} 0%, #0D0D0D 100%)`,
        border: `1px solid ${hovered ? COLORS.borderStrong : COLORS.border}`,
        borderRadius: 18,
        boxShadow: hovered
          ? "0 16px 44px -22px rgba(0,0,0,0.6)"
          : "0 10px 32px -20px rgba(0,0,0,0.55)",
        backdropFilter: "blur(20px)",
        transition: "all 0.3s ease",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function Pill({ children, style, active }) {
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        padding: "5px 12px", borderRadius: 999, fontSize: 12, fontWeight: 500,
        letterSpacing: 0.3,
        background: active ? COLORS.goldSoft : "rgba(255,255,255,0.03)",
        border: `1px solid ${active ? COLORS.borderStrong : COLORS.border}`,
        color: active ? COLORS.gold : COLORS.textDim,
        ...style,
      }}
    >
      {children}
    </span>
  );
}

/* =====================================================================================
   ROTATING HERO TEXT
===================================================================================== */

function RotatingHeroText({ texts }) {
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState("visible"); // visible | exiting | entering

  useEffect(() => {
    let holdTimer, enterTimer, rafId;

    const cycle = () => {
      holdTimer = setTimeout(() => {
        setPhase("exiting");
        enterTimer = setTimeout(() => {
          setIndex((i) => (i + 1) % texts.length);
          setPhase("entering");
          rafId = requestAnimationFrame(() => {
            requestAnimationFrame(() => setPhase("visible"));
          });
          cycle();
        }, 350);
      }, 4000);
    };

    cycle();
    return () => {
      clearTimeout(holdTimer);
      clearTimeout(enterTimer);
      cancelAnimationFrame(rafId);
    };
  }, [texts]);

  const style = {
    fontSize: "clamp(14px, 2vw, 16.5px)",
    fontWeight: 500,
    color: COLORS.text,
    transition: phase === "entering" ? "none" : "opacity 350ms ease, transform 350ms ease",
    opacity: phase === "visible" ? 1 : 0,
    transform:
      phase === "exiting" ? "translateY(-8px)" :
      phase === "entering" ? "translateY(8px)" :
      "translateY(0)",
  };

  return (
    <div style={{ height: 26, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", marginTop: 14 }}>
      <span style={style}>{texts[index]}</span>
    </div>
  );
}

/* =====================================================================================
   NAVBAR
===================================================================================== */

function Navbar({ t, lang, setLang, onNavClick, isLoggedIn, onToggleLogin }) {
  const [langOpen, setLangOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "rgba(11,11,11,0.72)", backdropFilter: "blur(16px)",
        borderBottom: `1px solid ${COLORS.divider}`,
      }}
    >
      <div style={{ maxWidth: 1280, margin: "0 auto", padding: "0 24px" }} className="flex items-center justify-between">
        <div className="flex items-center" style={{ height: 68, gap: 12 }}>
          <div
            style={{
              width: 34, height: 34, borderRadius: 10,
              background: COLORS.gold,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          >
            <Sparkles size={17} color="#0B0B0B" strokeWidth={2.4} />
          </div>
          <span style={{ fontWeight: 600, fontSize: 16.5, letterSpacing: 0.2, color: COLORS.text }}>
            FX Vision <span style={{ color: COLORS.gold }}>AI</span>
          </span>
        </div>

        <nav className="hidden md:flex items-center" style={{ gap: 4 }}>
          {[
            ["markets", t.nav.markets],
            ["ai", t.nav.ai],
            ["learn", t.nav.learn],
            ["pricing", t.nav.pricing],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => onNavClick(key)}
              style={{
                padding: "8px 16px", fontSize: 13.5, color: COLORS.textDim,
                background: "transparent", border: "none", cursor: "pointer",
                borderRadius: 8, transition: "all 0.2s ease", fontWeight: 450,
              }}
              onMouseEnter={(e) => { e.currentTarget.style.color = COLORS.text; e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = COLORS.textDim; e.currentTarget.style.background = "transparent"; }}
            >
              {label}
            </button>
          ))}
        </nav>

        <div className="flex items-center" style={{ gap: 10, height: 68 }}>
          <div style={{ position: "relative" }}>
            <button
              onClick={() => setLangOpen((v) => !v)}
              style={{
                display: "flex", alignItems: "center", gap: 6, padding: "7px 12px",
                borderRadius: 999, background: "rgba(255,255,255,0.03)",
                border: `1px solid ${COLORS.border}`, color: COLORS.textDim,
                cursor: "pointer", fontSize: 12.5,
              }}
            >
              <Globe size={13} />
              {lang === "en" ? "EN" : "فا"}
              <ChevronDown size={12} />
            </button>
            {langOpen && (
              <div
                style={{
                  position: "absolute", top: "115%", insetInlineEnd: 0, minWidth: 120,
                  background: COLORS.card, border: `1px solid ${COLORS.borderStrong}`,
                  borderRadius: 12, overflow: "hidden", boxShadow: "0 20px 50px -15px rgba(0,0,0,0.7)",
                  animation: "fadeSlideDown 0.18s ease",
                }}
              >
                {["en", "fa"].map((l) => (
                  <div
                    key={l}
                    onClick={() => { setLang(l); setLangOpen(false); }}
                    style={{
                      padding: "10px 14px", fontSize: 13, cursor: "pointer",
                      color: lang === l ? COLORS.gold : COLORS.textDim,
                      background: lang === l ? COLORS.goldSoft : "transparent",
                    }}
                  >
                    {l === "en" ? "English" : "فارسی"}
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onToggleLogin}
            className="hidden sm:flex items-center"
            style={{ gap: 8, padding: "6px 14px 6px 6px", borderRadius: 999, background: "rgba(255,255,255,0.03)", border: `1px solid ${COLORS.border}`, cursor: "pointer" }}
          >
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "rgba(200,168,90,0.18)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <User size={13} color={COLORS.gold} />
            </div>
            <span style={{ fontSize: 12.5, color: COLORS.textDim }}>{isLoggedIn ? t.signOut : t.signIn}</span>
          </button>

          <button
            className="md:hidden"
            onClick={() => setMobileOpen((v) => !v)}
            style={{ background: "transparent", border: "none", color: COLORS.text, cursor: "pointer" }}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden" style={{ borderTop: `1px solid ${COLORS.divider}`, padding: "8px 20px 16px" }}>
          {[
            ["markets", t.nav.markets],
            ["ai", t.nav.ai],
            ["learn", t.nav.learn],
            ["pricing", t.nav.pricing],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => { onNavClick(key); setMobileOpen(false); }}
              style={{
                display: "block", width: "100%", textAlign: "start", padding: "12px 4px",
                background: "transparent", border: "none", color: COLORS.textDim, fontSize: 14.5,
                borderBottom: `1px solid ${COLORS.divider}`,
              }}
            >
              {label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}

/* =====================================================================================
   CHART SECTION (TradingView embed)
===================================================================================== */

/* --------------------------------- Binance market data --------------------------------- */

async function fetchBinanceKlines(symbol, interval) {
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=300`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Binance request failed (${res.status})`);
  const raw = await res.json();
  if (!Array.isArray(raw) || raw.length === 0) throw new Error("Empty candle response");
  return raw.map((k) => ({
    time: k[0],
    open: parseFloat(k[1]),
    high: parseFloat(k[2]),
    low: parseFloat(k[3]),
    close: parseFloat(k[4]),
  }));
}

function formatTickTime(ms, interval) {
  const d = new Date(ms);
  if (interval === "1d") {
    return `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
  }
  const hh = String(d.getUTCHours()).padStart(2, "0");
  const mm = String(d.getUTCMinutes()).padStart(2, "0");
  return `${hh}:${mm}`;
}

function useElementSize() {
  const ref = useRef(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  useEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const ro = new ResizeObserver((entries) => {
      const { width, height } = entries[0].contentRect;
      setSize({ width, height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, size];
}

/* =====================================================================================
   CHART SECTION — native candlesticks, real Binance data, zoom/pan/crosshair
===================================================================================== */

function CandlestickChart({ symbol, interval, t }) {
  const [containerRef, size] = useElementSize();
  const svgRef = useRef(null);
  const [data, setData] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [retryTick, setRetryTick] = useState(0);
  const xScaleRef = useRef(null);

  // Fetch real candles directly from Binance's public REST API.
  useEffect(() => {
    let cancelled = false;
    setStatus("loading");
    setData(null);
    fetchBinanceKlines(symbol, interval)
      .then((rows) => {
        if (cancelled) return;
        setData(rows);
        setStatus("ready");
      })
      .catch(() => {
        if (cancelled) return;
        setStatus("error");
      });
    return () => { cancelled = true; };
  }, [symbol, interval, retryTick]);

  // Render / re-render with d3 whenever data or container size changes.
  useEffect(() => {
    if (status !== "ready" || !data || !svgRef.current || size.width < 10 || size.height < 10) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 8, right: 54, bottom: 22, left: 4 };
    const width = Math.max(10, size.width - margin.left - margin.right);
    const height = Math.max(10, size.height - margin.top - margin.bottom);

    const baseX = d3.scaleLinear().domain([-0.5, data.length - 0.5]).range([0, width]);
    const lowMin = d3.min(data, (d) => d.low);
    const highMax = d3.max(data, (d) => d.high);
    const yPad = (highMax - lowMin) * 0.1 || 1;
    const y = d3.scaleLinear().domain([lowMin - yPad, highMax + yPad]).range([height, 0]);

    const root = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

    const clipId = `fxv-clip-${symbol}-${interval}`;
    svg.append("defs").append("clipPath").attr("id", clipId)
      .append("rect").attr("width", width).attr("height", height);

    const gridG = root.append("g");
    const plot = root.append("g").attr("clip-path", `url(#${clipId})`);
    const yAxisG = root.append("g").attr("transform", `translate(${width},0)`);
    const xAxisG = root.append("g").attr("transform", `translate(0,${height})`);
    const crosshairG = root.append("g").style("display", "none");
    const chVLine = crosshairG.append("line")
      .attr("y1", 0).attr("y2", height)
      .attr("stroke", COLORS.gold).attr("stroke-width", 1).attr("stroke-dasharray", "3,3");
    const chHLine = crosshairG.append("line")
      .attr("x1", 0).attr("x2", width)
      .attr("stroke", COLORS.gold).attr("stroke-width", 1).attr("stroke-dasharray", "3,3");
    const chLabel = crosshairG.append("text")
      .attr("fill", COLORS.gold).attr("font-size", 10).attr("font-family", FONT_MONO);

    function render(xs) {
      xScaleRef.current = xs;
      const [d0, d1] = xs.domain();
      const i0 = Math.max(0, Math.floor(d0));
      const i1 = Math.min(data.length - 1, Math.ceil(d1));
      const visible = data.slice(i0, i1 + 1).map((d, k) => ({ ...d, idx: i0 + k }));
      const step = xs(1) - xs(0);
      const candleW = Math.max(1.5, Math.min(step * 0.62, 22));

      gridG.selectAll("line.hgrid")
        .data(y.ticks(5))
        .join("line")
        .attr("class", "hgrid")
        .attr("x1", 0).attr("x2", width)
        .attr("y1", (d) => y(d)).attr("y2", (d) => y(d))
        .attr("stroke", "rgba(255,255,255,0.05)");

      yAxisG.call(d3.axisRight(y).ticks(5).tickSize(0).tickFormat((d) => d3.format(d < 10 ? ",.4f" : ",.2f")(d)))
        .call((g) => g.select(".domain").remove())
        .selectAll("text").attr("fill", COLORS.textFaint).attr("font-size", 10).attr("font-family", FONT_MONO).attr("dx", 6);

      const tickIdx = d3.range(5).map((k) => Math.round(i0 + (k / 4) * (i1 - i0))).filter((v, i, arr) => arr.indexOf(v) === i);
      xAxisG.selectAll("*").remove();
      xAxisG.selectAll("text")
        .data(tickIdx)
        .join("text")
        .attr("x", (d) => xs(d))
        .attr("y", 16)
        .attr("text-anchor", "middle")
        .attr("fill", COLORS.textFaint)
        .attr("font-size", 10)
        .attr("font-family", FONT_MONO)
        .text((d) => (data[d] ? formatTickTime(data[d].time, interval) : ""));

      const candles = plot.selectAll("g.candle").data(visible, (d) => d.idx);
      candles.exit().remove();
      const entered = candles.enter().append("g").attr("class", "candle");
      entered.append("line").attr("class", "wick");
      entered.append("rect").attr("class", "body");
      const merged = entered.merge(candles);

      merged.select("line.wick")
        .attr("x1", (d) => xs(d.idx)).attr("x2", (d) => xs(d.idx))
        .attr("y1", (d) => y(d.high)).attr("y2", (d) => y(d.low))
        .attr("stroke", (d) => (d.close >= d.open ? COLORS.green : COLORS.red))
        .attr("stroke-width", 1);

      merged.select("rect.body")
        .attr("x", (d) => xs(d.idx) - candleW / 2)
        .attr("y", (d) => y(Math.max(d.open, d.close)))
        .attr("width", candleW)
        .attr("height", (d) => Math.max(1, Math.abs(y(d.open) - y(d.close))))
        .attr("fill", (d) => (d.close >= d.open ? COLORS.green : COLORS.red));
    }

    render(baseX);

    // Zoom + pan (wheel to zoom, drag to pan) — native browser gestures, no external deps.
    const zoom = d3.zoom()
      .scaleExtent([1, 12])
      .translateExtent([[0, 0], [width, height]])
      .extent([[0, 0], [width, height]])
      .on("zoom", (event) => render(event.transform.rescaleX(baseX)));

    const overlay = svg.append("rect")
      .attr("x", margin.left).attr("y", margin.top)
      .attr("width", width).attr("height", height)
      .attr("fill", "transparent")
      .style("cursor", "crosshair")
      .call(zoom);

    overlay.on("mousemove", function (event) {
      const xs = xScaleRef.current || baseX;
      const [mx, my] = d3.pointer(event, this);
      const idx = Math.round(xs.invert(mx));
      const d = data[Math.max(0, Math.min(data.length - 1, idx))];
      if (!d) return;
      crosshairG.style("display", null);
      chVLine.attr("x1", xs(idx)).attr("x2", xs(idx));
      chHLine.attr("y1", my).attr("y2", my);
      chLabel
        .attr("x", Math.min(width - 6, xs(idx) + 8))
        .attr("y", Math.max(12, my - 8))
        .text(`O ${d.open.toFixed(2)}  H ${d.high.toFixed(2)}  L ${d.low.toFixed(2)}  C ${d.close.toFixed(2)}`);
    }).on("mouseleave", () => crosshairG.style("display", "none"));

  }, [data, status, size.width, size.height, symbol, interval]);

  return (
    <div ref={containerRef} style={{ position: "relative", width: "100%", height: "100%" }}>
      {status === "loading" && (
        <div style={{ position: "absolute", inset: 0, padding: 12, display: "flex", flexDirection: "column", justifyContent: "flex-end", gap: 6 }}>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: "70%" }}>
            {Array.from({ length: 40 }).map((_, i) => (
              <div
                key={i}
                style={{
                  flex: 1, borderRadius: 2,
                  height: `${20 + ((i * 37) % 60)}%`,
                  background: "rgba(255,255,255,0.05)",
                  animation: `skeletonPulse 1.3s ease-in-out ${(i % 8) * 0.06}s infinite`,
                }}
              />
            ))}
          </div>
          <div style={{ height: 1, background: "rgba(255,255,255,0.05)", width: "100%" }} />
        </div>
      )}
      {status === "error" && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
          <AlertTriangle size={22} color={COLORS.textFaint} />
          <span style={{ fontSize: 13, color: COLORS.textDim }}>{t.chartError}</span>
          <button
            onClick={() => setRetryTick((k) => k + 1)}
            style={{
              display: "flex", alignItems: "center", gap: 6, padding: "8px 16px", borderRadius: 8,
              background: COLORS.goldSoft, border: `1px solid ${COLORS.borderStrong}`, color: COLORS.gold,
              fontSize: 12.5, cursor: "pointer",
            }}
          >
            <RefreshCw size={13} /> {t.chartRetry}
          </button>
        </div>
      )}
      <svg ref={svgRef} width="100%" height="100%" style={{ display: status === "ready" ? "block" : "none" }} />
    </div>
  );
}

function ChartSection({ t, coin, fullscreen, setFullscreen, interval, setInterval }) {
  return (
    <div
      style={{
        position: fullscreen ? "fixed" : "relative",
        inset: fullscreen ? 0 : "auto",
        zIndex: fullscreen ? 100 : "auto",
        background: fullscreen ? COLORS.bg : "transparent",
        padding: fullscreen ? 12 : 0,
        animation: fullscreen ? "fadeIn 0.25s ease" : "none",
      }}
    >
      <GlassCard
        style={{
          height: fullscreen ? "calc(100vh - 24px)" : "min(500px, 72vh)",
          padding: 6, position: "relative", overflow: "hidden",
        }}
      >
        <div className="flex items-center justify-between flex-wrap" style={{ padding: "8px 10px 10px", gap: 10 }}>
          <div className="flex items-center" style={{ gap: 10 }}>
            <span style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.text }}>{coin.id}/USDT</span>
            <span
              style={{
                fontSize: 12, fontFamily: FONT_MONO, color: coin.change >= 0 ? COLORS.green : COLORS.red,
                display: "flex", alignItems: "center", gap: 3,
              }}
            >
              {coin.change >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
              {coin.change >= 0 ? "+" : ""}{coin.change}%
            </span>
          </div>

          <div className="flex items-center" style={{ gap: 6 }}>
            <div className="flex items-center" style={{ gap: 3, padding: 3, borderRadius: 8, background: "rgba(255,255,255,0.03)", border: `1px solid ${COLORS.border}` }}>
              {TIMEFRAMES.map((tf) => (
                <button
                  key={tf}
                  onClick={() => setInterval(tf)}
                  style={{
                    padding: "5px 10px", borderRadius: 6, border: "none", cursor: "pointer",
                    fontSize: 11.5, fontFamily: FONT_MONO, fontWeight: 600,
                    background: interval === tf ? COLORS.gold : "transparent",
                    color: interval === tf ? "#0B0B0B" : COLORS.textDim,
                    transition: "all 0.15s ease",
                  }}
                >
                  {tf.toUpperCase()}
                </button>
              ))}
            </div>
            <button
              onClick={() => setFullscreen((v) => !v)}
              style={{
                display: "flex", alignItems: "center", gap: 6, padding: "6px 12px",
                borderRadius: 8, background: "rgba(255,255,255,0.04)", border: `1px solid ${COLORS.border}`,
                color: COLORS.textDim, fontSize: 12, cursor: "pointer",
              }}
            >
              {fullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
              <span className="hidden sm:inline">{fullscreen ? t.exitFullscreen : t.fullscreen}</span>
            </button>
          </div>
        </div>
        <div style={{ height: "calc(100% - 50px)", borderRadius: 14, overflow: "hidden" }}>
          <CandlestickChart symbol={coin.binance} interval={interval} t={t} />
        </div>
      </GlassCard>
    </div>
  );
}

/* =====================================================================================
   ANALYZE BUTTON + LOADING SEQUENCE
===================================================================================== */

function AnalyzeButton({ t, onAnalyze, loading }) {
  return (
    <button
      onClick={onAnalyze}
      disabled={loading}
      style={{
        position: "relative", overflow: "hidden",
        padding: "16px 42px", borderRadius: 14, border: "none", cursor: loading ? "default" : "pointer",
        background: COLORS.gold,
        color: "#0B0B0B", fontWeight: 650, fontSize: 15.5, letterSpacing: 0.2,
        display: "inline-flex", alignItems: "center", gap: 10,
        transition: "transform 0.2s ease",
        opacity: loading ? 0.85 : 1,
      }}
      onMouseEnter={(e) => { if (!loading) { e.currentTarget.style.transform = "translateY(-2px)"; } }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; }}
    >
      <Zap size={17} strokeWidth={2.3} />
      {loading ? t.analyzing : t.analyze}
    </button>
  );
}

function ScanSequence({ steps }) {
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    setActiveIdx(0);
    const interval = setInterval(() => {
      setActiveIdx((i) => Math.min(i + 1, steps.length - 1));
    }, 620);
    return () => clearInterval(interval);
  }, [steps]);

  return (
    <GlassCard style={{ padding: 28, marginTop: 28 }}>
      <div style={{ position: "relative", height: 2, background: "rgba(255,255,255,0.05)", borderRadius: 2, marginBottom: 22, overflow: "hidden" }}>
        <div
          style={{
            position: "absolute", top: 0, left: 0, height: "100%", width: "40%",
            background: `linear-gradient(90deg, transparent, ${COLORS.gold}, transparent)`,
            animation: "scanBar 1.4s ease-in-out infinite",
          }}
        />
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {steps.map((step, i) => (
          <div key={i} className="flex items-center" style={{ gap: 12, opacity: i <= activeIdx ? 1 : 0.35, transition: "opacity 0.3s ease" }}>
            <div
              style={{
                width: 18, height: 18, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                border: `1.5px solid ${i < activeIdx ? COLORS.gold : COLORS.border}`,
                background: i < activeIdx ? COLORS.goldSoft : "transparent",
              }}
            >
              {i < activeIdx ? <Check size={11} color={COLORS.gold} /> : (
                i === activeIdx ? <div style={{ width: 6, height: 6, borderRadius: "50%", background: COLORS.gold, animation: "pulse 1s ease-in-out infinite" }} /> : null
              )}
            </div>
            <span style={{ fontFamily: FONT_MONO, fontSize: 13, color: i <= activeIdx ? COLORS.text : COLORS.textFaint }}>{step}</span>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}

/* =====================================================================================
   RESULT CARD
===================================================================================== */

function RecPill({ rec, t }) {
  const map = {
    BUY: { color: COLORS.green, label: t.buy, Icon: TrendingUp },
    SELL: { color: COLORS.red, label: t.sell, Icon: TrendingDown },
    HOLD: { color: COLORS.gold, label: t.hold, Icon: Minus },
  };
  const { color, label, Icon } = map[rec];
  return (
    <div
      style={{
        display: "inline-flex", alignItems: "center", gap: 10, padding: "10px 22px",
        borderRadius: 14, background: `${color}14`, border: `1px solid ${color}55`,
      }}
    >
      <Icon size={20} color={color} />
      <span style={{ fontSize: 22, fontWeight: 700, color, letterSpacing: 0.5 }}>{label}</span>
    </div>
  );
}

function StatBlock({ label, value, mono = true }) {
  return (
    <div>
      <div style={{ fontSize: 11.5, color: COLORS.textFaint, marginBottom: 4, textTransform: "uppercase", letterSpacing: 0.6 }}>{label}</div>
      <div style={{ fontSize: 15.5, color: COLORS.text, fontWeight: 600, fontFamily: mono ? FONT_MONO : "inherit" }}>{value}</div>
    </div>
  );
}

function ScoreBar({ label, value }) {
  const color = value >= 60 ? COLORS.green : value <= 40 ? COLORS.red : COLORS.gold;
  return (
    <div>
      <div className="flex items-center justify-between" style={{ marginBottom: 6 }}>
        <span style={{ fontSize: 12.5, color: COLORS.textDim }}>{label}</span>
        <span style={{ fontSize: 12.5, fontFamily: FONT_MONO, color }}>{value}</span>
      </div>
      <div style={{ height: 6, borderRadius: 4, background: "rgba(255,255,255,0.05)", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${value}%`, background: color, borderRadius: 4, transition: "width 0.8s cubic-bezier(.22,1,.36,1)" }} />
      </div>
    </div>
  );
}

function ReasonRow({ reason, t, lang, learning }) {
  const [open, setOpen] = useState(false);
  const data = reason[lang][reason.direction];
  const dirColor = reason.direction === "bullish" ? COLORS.green : reason.direction === "bearish" ? COLORS.red : COLORS.textDim;

  return (
    <div style={{ borderBottom: `1px solid ${COLORS.divider}`, padding: "16px 0" }}>
      <div
        className="flex items-center justify-between"
        style={{ cursor: learning ? "pointer" : "default" }}
        onClick={() => learning && setOpen((v) => !v)}
      >
        <div className="flex items-center" style={{ gap: 10 }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: dirColor, flexShrink: 0 }} />
          <span style={{ fontSize: 14, color: COLORS.text }}>{data[0]}</span>
        </div>
        {learning && (
          <ChevronDown size={15} color={COLORS.textFaint} style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.25s ease" }} />
        )}
      </div>
      {learning && open && (
        <div
          style={{
            marginTop: 10, marginInlineStart: 16, padding: "12px 16px", borderRadius: 10,
            background: "rgba(200,168,90,0.05)", border: `1px solid ${COLORS.border}`,
            animation: "fadeIn 0.25s ease",
          }}
        >
          <div style={{ fontSize: 11, color: COLORS.gold, marginBottom: 6, fontWeight: 600, letterSpacing: 0.3 }}>{t.whatDoesMean}</div>
          <div style={{ fontSize: 13.5, color: COLORS.textDim, lineHeight: 1.65 }}>{data[1]}</div>
        </div>
      )}
    </div>
  );
}

function ResultCard({ t, lang, result, mode, coin }) {
  const riskLabel = { low: t.riskLow, medium: t.riskMed, high: t.riskHigh }[result.risk];
  const riskColor = { low: COLORS.green, medium: COLORS.gold, high: COLORS.red }[result.risk];

  return (
    <div style={{ marginTop: 28, display: "grid", gap: 20 }} className="lg:grid-cols-5">
      <GlassCard style={{ padding: 28 }} className="lg:col-span-3" hover>
        <div className="flex items-center justify-between flex-wrap" style={{ gap: 16, marginBottom: 26 }}>
          <RecPill rec={result.recommendation} t={t} />
          <div className="flex items-center" style={{ gap: 20 }}>
            <StatBlock label={t.confidence} value={`${result.confidence}%`} />
            <StatBlock label={t.risk} value={riskLabel} mono={false} />
          </div>
        </div>

        <div style={{ height: 1, background: COLORS.divider, margin: "20px 0" }} />

        <div className="grid grid-cols-2 sm:grid-cols-4" style={{ gap: 20 }}>
          <StatBlock label={t.entryZone} value={`${result.entryLow} – ${result.entryHigh}`} />
          <StatBlock label={t.takeProfit} value={result.tp} />
          <StatBlock label={t.stopLoss} value={result.sl} />
          <StatBlock label={t.holdingTime} value={result.holdingTime} mono={false} />
        </div>

        <div style={{ height: 1, background: COLORS.divider, margin: "24px 0" }} />

        <div style={{ fontSize: 12.5, color: COLORS.gold, fontWeight: 600, letterSpacing: 0.4, marginBottom: 6, textTransform: "uppercase" }}>{t.reasons}</div>
        <div>
          {result.reasons.map((r, i) => (
            <ReasonRow key={i} reason={r} t={t} lang={lang} learning={mode === "learning"} />
          ))}
        </div>
      </GlassCard>

      <GlassCard style={{ padding: 28 }} className="lg:col-span-2" hover>
        <div style={{ fontSize: 12.5, color: COLORS.gold, fontWeight: 600, letterSpacing: 0.4, marginBottom: 20, textTransform: "uppercase" }}>{t.scores}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <ScoreBar label={t.onchain} value={result.scores.onchain} />
          <ScoreBar label={t.technical} value={result.scores.technical} />
          <ScoreBar label={t.derivatives} value={result.scores.derivatives} />
          <ScoreBar label={t.sentiment} value={result.scores.sentiment} />
        </div>
        <div style={{ height: 1, background: COLORS.divider, margin: "22px 0" }} />
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 12, color: COLORS.textFaint, marginBottom: 8, letterSpacing: 0.5 }}>{t.overall.toUpperCase()}</div>
          <div style={{ position: "relative", width: 120, height: 120, margin: "0 auto" }}>
            <svg viewBox="0 0 120 120" style={{ width: "100%", height: "100%", transform: "rotate(-90deg)" }}>
              <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
              <circle
                cx="60" cy="60" r="52" fill="none" stroke={COLORS.gold} strokeWidth="8" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 52}
                strokeDashoffset={2 * Math.PI * 52 * (1 - result.scores.overall / 100)}
                style={{ transition: "stroke-dashoffset 1s cubic-bezier(.22,1,.36,1)" }}
              />
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, fontWeight: 700, color: COLORS.text, fontFamily: FONT_MONO }}>
              {result.scores.overall}
            </div>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}

/* =====================================================================================
   MODE TOGGLE
===================================================================================== */

function ModeToggle({ t, mode, setMode }) {
  return (
    <div style={{ marginTop: 24 }}>
      <div
        style={{
          display: "inline-flex", padding: 4, borderRadius: 12,
          background: "rgba(255,255,255,0.03)", border: `1px solid ${COLORS.border}`,
        }}
      >
        {[["trader", t.modeTrader, Target], ["learning", t.modeLearning, GraduationCap]].map(([key, label, Icon]) => (
          <button
            key={key}
            onClick={() => setMode(key)}
            style={{
              display: "flex", alignItems: "center", gap: 7, padding: "9px 18px", borderRadius: 9,
              border: "none", cursor: "pointer", fontSize: 13, fontWeight: 550,
              background: mode === key ? COLORS.gold : "transparent",
              color: mode === key ? "#0B0B0B" : COLORS.textDim,
              transition: "all 0.25s ease",
            }}
          >
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>
      <div style={{ fontSize: 12, color: COLORS.textFaint, marginTop: 8 }}>{t.modeSub}</div>
    </div>
  );
}

/* =====================================================================================
   WATCHLIST
===================================================================================== */

function Watchlist({ t, coins, selected, onSelect, favorites, toggleFav }) {
  return (
    <GlassCard style={{ padding: 22 }}>
      <div style={{ fontSize: 12.5, color: COLORS.gold, fontWeight: 600, letterSpacing: 0.4, marginBottom: 16, textTransform: "uppercase" }}>{t.watchlist}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {coins.map((c) => (
          <div
            key={c.id}
            onClick={() => onSelect(c)}
            className="flex items-center justify-between"
            style={{
              padding: "12px 10px", borderRadius: 10, cursor: "pointer",
              background: selected.id === c.id ? COLORS.goldSoft : "transparent",
              border: `1px solid ${selected.id === c.id ? COLORS.borderStrong : "transparent"}`,
              transition: "all 0.2s ease",
            }}
          >
            <div className="flex items-center" style={{ gap: 12 }}>
              <button
                onClick={(e) => { e.stopPropagation(); toggleFav(c.id); }}
                style={{ background: "transparent", border: "none", cursor: "pointer", padding: 2, display: "flex" }}
              >
                <Star size={15} color={favorites.includes(c.id) ? COLORS.gold : COLORS.textFaint} fill={favorites.includes(c.id) ? COLORS.gold : "none"} />
              </button>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.text }}>{c.id}</div>
                <div style={{ fontSize: 11, color: COLORS.textFaint }}>{c.name}</div>
              </div>
            </div>
            <div style={{ textAlign: "end" }}>
              <div style={{ fontSize: 13, fontFamily: FONT_MONO, color: COLORS.text }}>{c.price >= 1 ? c.price.toLocaleString() : c.price}</div>
              <div style={{ fontSize: 11.5, fontFamily: FONT_MONO, color: c.change >= 0 ? COLORS.green : COLORS.red }}>
                {c.change >= 0 ? "+" : ""}{c.change}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}

/* =====================================================================================
   ON-CHAIN METRICS (beginner-friendly, expandable)
===================================================================================== */

function OnchainMetricCard({ t, lang, item }) {
  const [open, setOpen] = useState(false);
  const d = item[lang];
  const Icon = item.icon;
  const rows = [
    [t.onc_what, d.what],
    [t.onc_why, d.why],
    [t.onc_today, d.today],
    [t.onc_example, d.example],
    [t.onc_takeaway, d.takeaway],
  ];
  return (
    <GlassCard style={{ padding: 0, overflow: "hidden" }}>
      <div
        onClick={() => setOpen((v) => !v)}
        className="flex items-center justify-between"
        style={{ padding: "18px 20px", cursor: "pointer" }}
      >
        <div className="flex items-center" style={{ gap: 12 }}>
          <div style={{ width: 34, height: 34, borderRadius: 9, background: COLORS.goldSoft, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Icon size={16} color={COLORS.gold} />
          </div>
          <span style={{ fontSize: 14.5, fontWeight: 600, color: COLORS.text }}>{d.name}</span>
        </div>
        <ChevronDown size={16} color={COLORS.textFaint} style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.25s ease" }} />
      </div>
      {open && (
        <div style={{ padding: "0 20px 20px", animation: "fadeIn 0.25s ease" }}>
          <div style={{ height: 1, background: COLORS.divider, marginBottom: 16 }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {rows.map(([label, text], i) => (
              <div key={i}>
                <div style={{ fontSize: 11, color: COLORS.gold, fontWeight: 600, letterSpacing: 0.3, marginBottom: 4 }}>{label}</div>
                <p style={{ fontSize: 13.5, color: COLORS.textDim, lineHeight: 1.7, margin: 0 }}>{text}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </GlassCard>
  );
}

function OnchainMetricsSection({ t, lang }) {
  return (
    <div style={{ marginTop: 32 }}>
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 12.5, color: COLORS.gold, fontWeight: 600, letterSpacing: 0.4, marginBottom: 6, textTransform: "uppercase" }}>{t.onchainTitle}</div>
        <p style={{ fontSize: 13, color: COLORS.textFaint }}>{t.onchainSub}</p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {ONCHAIN_METRICS.map((item, i) => (
          <OnchainMetricCard key={i} t={t} lang={lang} item={item} />
        ))}
      </div>
    </div>
  );
}

/* =====================================================================================
   GLOSSARY
===================================================================================== */

function GlossarySection({ t, lang }) {
  return (
    <section id="learn-section" style={{ maxWidth: 1280, margin: "0 auto", padding: "80px 24px 40px" }}>
      <div style={{ textAlign: "center", marginBottom: 44 }}>
        <Pill><BookOpen size={12} /> {t.nav.learn}</Pill>
        <h2 style={{ fontSize: 32, fontWeight: 700, color: COLORS.text, marginTop: 16, letterSpacing: -0.5 }}>{t.glossaryTitle}</h2>
        <p style={{ color: COLORS.textDim, marginTop: 8, fontSize: 15 }}>{t.glossarySub}</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3" style={{ gap: 16 }}>
        {GLOSSARY.map((item, i) => {
          const [name, desc] = item[lang];
          const Icon = item.icon;
          return (
            <GlassCard key={i} style={{ padding: 22 }} hover>
              <div className="flex items-center" style={{ gap: 10, marginBottom: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: 9, background: COLORS.goldSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon size={16} color={COLORS.gold} />
                </div>
                <span style={{ fontSize: 14.5, fontWeight: 600, color: COLORS.text }}>{name}</span>
              </div>
              <p style={{ fontSize: 13, color: COLORS.textDim, lineHeight: 1.6 }}>{desc}</p>
            </GlassCard>
          );
        })}
      </div>
    </section>
  );
}

/* =====================================================================================
   PRICING
===================================================================================== */

function PricingSection({ t }) {
  const tiers = [
    { name: "Free", price: "$0", features: ["3 AI analyses / day", "Trader Mode", "Watchlist (4 assets)"], cta: t.getStarted },
    { name: "Pro", price: "$29", features: ["Unlimited AI analyses", "Learning Mode explanations", "Full indicator glossary", "Priority signal refresh"], cta: t.goPro, highlight: true },
    { name: "Elite", price: "$99", features: ["Everything in Pro", "Custom watchlists", "Advanced risk models", "1:1 onboarding session"], cta: t.contactUs },
  ];
  return (
    <section id="pricing-section" style={{ maxWidth: 1280, margin: "0 auto", padding: "40px 24px 90px" }}>
      <div style={{ textAlign: "center", marginBottom: 44 }}>
        <h2 style={{ fontSize: 32, fontWeight: 700, color: COLORS.text, letterSpacing: -0.5 }}>{t.pricingTitle}</h2>
        <p style={{ color: COLORS.textDim, marginTop: 8, fontSize: 15 }}>{t.pricingSub}</p>
      </div>
      <div className="grid sm:grid-cols-3" style={{ gap: 20 }}>
        {tiers.map((tier, i) => (
          <GlassCard
            key={i}
            style={{
              padding: 30,
              border: `1px solid ${tier.highlight ? COLORS.borderStrong : COLORS.border}`,
              transform: tier.highlight ? "translateY(-8px)" : "none",
              boxShadow: tier.highlight ? "0 16px 44px -22px rgba(0,0,0,0.6)" : undefined,
            }}
          >
            {tier.highlight && <Pill active style={{ marginBottom: 14 }}>Most Popular</Pill>}
            <div style={{ fontSize: 16, fontWeight: 600, color: COLORS.text, marginTop: tier.highlight ? 0 : 6 }}>{tier.name}</div>
            <div style={{ marginTop: 10, marginBottom: 20 }}>
              <span style={{ fontSize: 34, fontWeight: 700, color: COLORS.text, fontFamily: FONT_MONO }}>{tier.price}</span>
              <span style={{ fontSize: 13, color: COLORS.textFaint }}> {t.perMonth}</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 26 }}>
              {tier.features.map((f, j) => (
                <div key={j} className="flex items-center" style={{ gap: 9 }}>
                  <Check size={14} color={COLORS.gold} />
                  <span style={{ fontSize: 13, color: COLORS.textDim }}>{f}</span>
                </div>
              ))}
            </div>
            <button
              style={{
                width: "100%", padding: "12px 0", borderRadius: 10, border: `1px solid ${tier.highlight ? "transparent" : COLORS.border}`,
                background: tier.highlight ? COLORS.gold : "rgba(255,255,255,0.03)",
                color: tier.highlight ? "#0B0B0B" : COLORS.text, fontWeight: 600, fontSize: 13.5, cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}
            >
              {tier.cta} <ArrowRight size={14} />
            </button>
          </GlassCard>
        ))}
      </div>
    </section>
  );
}

/* =====================================================================================
   FOOTER
===================================================================================== */

function Footer({ t }) {
  return (
    <footer style={{ borderTop: `1px solid ${COLORS.divider}`, padding: "40px 24px" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }} className="flex items-center justify-between flex-wrap" >
        <div>
          <div className="flex items-center" style={{ gap: 8, marginBottom: 8 }}>
            <Sparkles size={15} color={COLORS.gold} />
            <span style={{ fontWeight: 600, color: COLORS.text, fontSize: 14 }}>FX Vision AI</span>
          </div>
          <p style={{ fontSize: 12.5, color: COLORS.textFaint, maxWidth: 380 }}>{t.footerTagline}</p>
        </div>
        <div style={{ fontSize: 11.5, color: COLORS.textFaint, textAlign: "end" }}>
          <div>© 2026 FX Vision AI. {t.footerRights}</div>
          <div style={{ marginTop: 4 }}>{t.disclaimer}</div>
        </div>
      </div>
    </footer>
  );
}

/* =====================================================================================
   MAIN APP
===================================================================================== */

export default function FXVisionAI() {
  const [lang, setLang] = useState("en");
  const [selectedCoin, setSelectedCoin] = useState(COINS[0]);
  const [favorites, setFavorites] = useState(["BTC", "ETH"]);
  const [mode, setMode] = useState("learning");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const chartRef = useRef(null);
  const learnRef = useRef(null);
  const pricingRef = useRef(null);

  const t = T[lang];

  const handleAnalyze = useCallback(() => {
    setLoading(true);
    setResult(null);
    setTimeout(() => {
      setResult(generateAnalysis(selectedCoin));
      setLoading(false);
    }, 3300);
  }, [selectedCoin]);

  const toggleFav = (id) => {
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]));
  };

  const scrollTo = (key) => {
    if (key === "learn" && learnRef.current) learnRef.current.scrollIntoView({ behavior: "smooth" });
    if (key === "pricing" && pricingRef.current) pricingRef.current.scrollIntoView({ behavior: "smooth" });
    if ((key === "markets" || key === "ai") && chartRef.current) chartRef.current.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    setResult(null);
  }, [selectedCoin]);

  return (
    <div
      dir={t.dir}
      style={{
        background: COLORS.bg, minHeight: "100vh", color: COLORS.text,
        fontFamily: t.font, overflowX: "hidden",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;450;500;600;650;700&family=IBM+Plex+Mono:wght@400;500;600&family=Vazirmatn:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; }
        ::selection { background: rgba(200,168,90,0.3); }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeSlideDown { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes scanBar { 0% { transform: translateX(-150%); } 100% { transform: translateX(350%); } }
        @keyframes pulse { 0%,100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.4; transform: scale(1.3); } }
        @keyframes spin { to { transform: rotate(360deg); } }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #0B0B0B; }
        ::-webkit-scrollbar-thumb { background: rgba(200,168,90,0.25); border-radius: 4px; }
        .grid { display: grid; }
        .flex { display: flex; }
        .hidden { display: none; }
        @media (min-width: 640px) {
          .sm\\:flex { display: flex; }
          .sm\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0,1fr)); }
          .sm\\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0,1fr)); }
          .sm\\:inline { display: inline; }
        }
        @media (min-width: 768px) {
          .md\\:flex { display: flex; }
          .md\\:hidden { display: none; }
        }
        @media (min-width: 1024px) {
          .lg\\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0,1fr)); }
          .lg\\:grid-cols-5 { grid-template-columns: repeat(5, minmax(0,1fr)); }
          .lg\\:col-span-2 { grid-column: span 2 / span 2; }
          .lg\\:col-span-3 { grid-column: span 3 / span 3; }
        }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .flex-wrap { flex-wrap: wrap; }
        .grid-cols-2 { grid-template-columns: repeat(2, minmax(0,1fr)); }
        .text-center { text-align: center; }
      `}</style>

      <Navbar t={t} lang={lang} setLang={setLang} onNavClick={scrollTo} isLoggedIn={isLoggedIn} onToggleLogin={() => setIsLoggedIn((v) => !v)} />

      {/* HERO */}
      <section style={{ maxWidth: 1280, margin: "0 auto", padding: isLoggedIn ? "36px 24px 24px" : "56px 24px 24px" }} ref={chartRef}>
        {!isLoggedIn && (
          <div style={{ textAlign: "center", marginBottom: 36, animation: "fadeUp 0.6s ease" }}>
            <Pill><Sparkles size={12} /> {t.heroKicker}</Pill>
            <h1 style={{ fontSize: "clamp(30px, 5vw, 52px)", fontWeight: 700, letterSpacing: -1, margin: "20px 0 10px", lineHeight: 1.08 }}>
              <span style={{ color: COLORS.text }}>{t.slogan1}</span>
            </h1>
            <p style={{ color: COLORS.gold, fontSize: "clamp(14px, 2vw, 17px)", fontWeight: 450, letterSpacing: 0.2 }}>{t.slogan2}</p>
            <RotatingHeroText texts={t.rotatingTexts} />
            <p style={{ fontSize: 12.5, color: COLORS.textFaint, opacity: 0.75, marginTop: 6 }}>{t.aiCaption}</p>
          </div>
        )}

        <ChartSection t={t} coin={selectedCoin} fullscreen={fullscreen} setFullscreen={setFullscreen} />

        <div className="flex items-center justify-between flex-wrap" style={{ marginTop: 22, gap: 16 }}>
          <div className="flex items-center" style={{ gap: 8, flexWrap: "wrap" }}>
            {COINS.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCoin(c)}
                style={{
                  padding: "8px 16px", borderRadius: 999, fontSize: 13, fontWeight: 550, cursor: "pointer",
                  background: selectedCoin.id === c.id ? COLORS.goldSoft : "rgba(255,255,255,0.03)",
                  border: `1px solid ${selectedCoin.id === c.id ? COLORS.borderStrong : COLORS.border}`,
                  color: selectedCoin.id === c.id ? COLORS.gold : COLORS.textDim,
                  transition: "all 0.2s ease",
                }}
              >
                {c.id}
              </button>
            ))}
          </div>
          <AnalyzeButton t={t} onAnalyze={handleAnalyze} loading={loading} />
        </div>

        {loading && <ScanSequence steps={t.scanSteps} />}

        {result && !loading && (
          <>
            <ModeToggle t={t} mode={mode} setMode={setMode} />
            <div style={{ animation: "fadeUp 0.5s ease" }}>
              <ResultCard t={t} lang={lang} result={result} mode={mode} coin={selectedCoin} />
              <OnchainMetricsSection t={t} lang={lang} />
            </div>
          </>
        )}
      </section>

      {/* MARKETS / WATCHLIST */}
      <section id="markets-section" style={{ maxWidth: 1280, margin: "0 auto", padding: "50px 24px" }}>
        <div className="grid" style={{ gap: 20 }} >
          <Watchlist t={t} coins={COINS} selected={selectedCoin} onSelect={setSelectedCoin} favorites={favorites} toggleFav={toggleFav} />
        </div>
      </section>

      <div ref={learnRef}>
        <GlossarySection t={t} lang={lang} />
      </div>

      <div ref={pricingRef}>
        <PricingSection t={t} />
      </div>

      <Footer t={t} />
    </div>
  );
}
